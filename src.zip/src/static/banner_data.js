export const BANNER_DATA = [
    {
        id: 0,
        title: "new collection",
        icon: "FaHeart",
        mainImgURL: "https://www.hogan.com/fashion/hoganNew/HXM5800EF21R5Q764D/HXM5800EF21R5Q764D-02.jpg?imwidth=475",
        hoverImgURL: "https://www.hogan.com/fashion/hoganNew/HXM5800EF21R5Q764D/HXM5800EF21R5Q764D-03.jpg?imwidth=475",
        itemName: "Sneakers Hogan H580 MULTICOLOUR",
        price: "€390"
    },
    {
        id: 1,
        title: "new collection",
        icon: "FaHeart",
        mainImgURL: "https://www.hogan.com/fashion/hoganNew/HXM5800DV42QI514ZZ/HXM5800DV42QI514ZZ-02.jpg?imwidth=475",
        hoverImgURL: "https://www.hogan.com/fashion/hoganNew/HXM5800DV42QI514ZZ/HXM5800DV42QI514ZZ-03.jpg?imwidth=475",
        itemName: "Sneakers Hogan H580 WHITE",
        price: "€390"
    },
    {
        id: 2,
        title: "new collection",
        icon: "FaHeart",
        mainImgURL: "https://www.hogan.com/fashion/hoganNew/HXM5800DV422X5849F/HXM5800DV422X5849F-02.jpg?imwidth=475",
        hoverImgURL: "https://www.hogan.com/fashion/hoganNew/HXM5800DV422X5849F/HXM5800DV422X5849F-03.jpg?imwidth=475",
        itemName: "Sneakers Hogan H580 BLUE",
        price: "€390"
    },
    {
        id: 3,
        title: "new collection",
        icon: "FaHeart",
        mainImgURL: "https://www.hogan.com/fashion/hoganNew/HXM5800DV422X5849G/HXM5800DV422X5849G-02.jpg?imwidth=475",
        hoverImgURL: "https://www.hogan.com/fashion/hoganNew/HXM5800EF21R5Q764D/HXM5800EF21R5Q764D-03.jpg?imwidth=475",
        itemName: "Sneakers Hogan H580 BROWN",
        price: "€390"
    },
    {
        id: 4,
        title: "new collection",
        icon: "FaHeart",
        mainImgURL: "https://www.hogan.com/fashion/hoganNew/HXM5800EF21B60894L/HXM5800EF21B60894L-02.jpg?imwidth=475",
        hoverImgURL: "https://www.hogan.com/fashion/hoganNew/HXM5800EF21B60894L/HXM5800EF21B60894L-03.jpg?imwidth=475",
        itemName: "Sneakers Hogan H580 MULTICOLOUR",
        price: "€390"
    },
    {
        id: 5,
        title: "new collection",
        icon: "FaHeart",
        mainImgURL: "https://www.hogan.com/fashion/hoganNew/HXM5800BE00LE9B001/HXM5800BE00LE9B001-02.jpg?imwidth=475",
        hoverImgURL: "https://www.hogan.com/fashion/hoganNew/HXM5800BE00LE9B001/HXM5800BE00LE9B001-03.jpg?imwidth=475",
        itemName: "Slip-on Hogan H580 WHITE",
        price: "€390"
    },
    {
        id: 6,
        title: "new collection",
        icon: "FaHeart",
        mainImgURL: "https://www.hogan.com/fashion/hoganNew/HXM5800BE00LE9B999/HXM5800BE00LE9B999-02.jpg?imwidth=475",
        hoverImgURL: "https://www.hogan.com/fashion/hoganNew/HXM5800BE00LE9B999/HXM5800BE00LE9B999-02.jpg?imwidth=475",
        itemName: "Slip-on Hogan H580 BLACK",
        price: "€390"
    },
    {
        id: 7,
        title: "new collection",
        icon: "FaHeart",
        mainImgURL: "https://www.hogan.com/fashion/hoganNew/HXM5800BE00HG0U828/HXM5800BE00HG0U828-02.jpg?imwidth=475",
        hoverImgURL: "https://www.hogan.com/fashion/hoganNew/HXM5800BE00HG0U828/HXM5800BE00HG0U828-03.jpg?imwidth=475",
        itemName: "Slip-on Hogan H580 BLUE",
        price: "€390"
    },
    {
        id: 8,
        title: "new collection",
        icon: "FaHeart",
        mainImgURL: "https://www.hogan.com/fashion/hoganNew/HXM5800DV422X5849F/HXM5800DV422X5849F-02.jpg?imwidth=475",
        hoverImgURL: "	https://www.hogan.com/fashion/hoganNew/HXM5800DV42Q3L15ZZ/HXM5800DV42Q3L15ZZ-03.jpg?imwidth=248",
        itemName: "Sneakers Hogan H580 BLUE",
        price: "€390"
    },
]