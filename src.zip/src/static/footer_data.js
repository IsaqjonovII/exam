export const FOOTER_DATA = [
    {
        title: "Explore",
        li: [
            "woman",
            "man",
            "inside hogan",
            "store locator"
        ]
    },
    {
        title: "Help",
        li: [
            "Contact us",
            "FAQs",
            "Customer service",
            "Accessibility statement"
        ]
    },
    {
        title: "Company",
        li: [
            "Tod's group",
            "work with us",
            "legal area",
            "privacy policy",
            "cookie policy - cookie settings"
        ]
    }
]

export const payments = [
    "https://cdn4.iconfinder.com/data/icons/flat-brand-logo-2/512/visa-512.png",
    "https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Mastercard-logo.svg/772px-Mastercard-logo.svg.png",
    " https://upload.wikimedia.org/wikipedia/commons/thumb/8/80/Maestro_2016.svg/616px-Maestro_2016.svg.png",
    "https://upload.wikimedia.org/wikipedia/commons/a/a4/Paypal_2014_logo.png",
    "https://1000logos.net/wp-content/uploads/2021/05/Diners-Club-International-logo.png",
    "https://www.freepnglogos.com/uploads/discover-png-logo/credit-cards-discover-png-logo-4.png",
    "https://upload.wikimedia.org/wikipedia/commons/e/e9/IDEAL_Logo.png",
    "https://www.freepnglogos.com/uploads/jcb/jcb-copyrighted-symbol-11.png",
    "https://user-images.githubusercontent.com/52973457/82835977-d9520b00-9ec5-11ea-8880-642813c05f24.png",
    "https://download.logo.wine/logo/Alipay/Alipay-Logo.wine.png",
    "https://upload.wikimedia.org/wikipedia/commons/thumb/1/1b/UnionPay_logo.svg/1024px-UnionPay_logo.svg.png"
]